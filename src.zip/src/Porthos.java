public class Porthos extends Cryptomonnaie{
    public Porthos(){
        super("POR", 500);
    }
}


